<?php $__env->startSection('title', 'Sliders - Admin Amolca'); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('libs/datatables/css/jquery.dataTables.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/admin/sliders/sliders.js')); ?>"></script>
<script src="<?php echo e(asset('libs/datatables/js/jquery.dataTables.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentClass', 'all-sliders'); ?>
<?php $__env->startSection('content'); ?>

	<div class="loader hidde">
		<div class="progress">
			<div class="indeterminate"></div>
		</div>
	</div>

	<input type="hidden" id="_token" value="<?php echo e(csrf_token()); ?>">

	<table class="table data-table sliders">
		<thead>
			<tr>
				<th class="title">Titulo:</th>
				<th class="slug">Slug:</th>
				<th class="specialty">Número de ítems:</th>
				<th class="specialty">Estado:</th>
				<th class="actions">Acciones:</th>
			</tr>
		</thead>

		<tbody>
		</tbody>

		<tfoot>
			
		</tfoot>
	</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.account', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>