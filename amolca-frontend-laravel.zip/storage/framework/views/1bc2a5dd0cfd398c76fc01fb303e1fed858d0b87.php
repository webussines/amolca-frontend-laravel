<?php
    $description = (isset($author->description)) ? $author->description : ' ';
?>

<?php $__env->startSection('title', 'Autor: ' . $author->name . ' - Admin Amolca'); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/admin/single-author.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('libs/select2/css/select2.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src='https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=1icfygu7db6ym5ibmufjkk2myppelx6v827sc9rq8xt1eo2n'></script>
<script src="<?php echo e(asset('libs/select2/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/admin/authors/single.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentClass', 'single single-author'); ?>
<?php $__env->startSection('content'); ?>

    <div class="loader top hidde">
        <div class="progress">
            <div class="indeterminate"></div>
        </div>
    </div>

    <div class="fixed-action-btn">
        <a class="btn-floating btn-large green save-resource">
            <span class="icon-save1"></span>
        </a>
        <a class="btn-floating btn-large red go-all-resources" href="/am-admin/autores">
            <span class="icon-cross"></span>
        </a>
    </div>

    <div class="row single section-header valign-wrapper">
		<div class="col s12 m10 l10">
			<p class="title"> <?php echo e($author->name); ?> </p>
		</div>
		<div class="col s12 m2 l2 actions">
            <a class="btn-floating btn-large green save-resource">
                <span class="icon-save1"></span>
            </a>
            <a class="btn-floating btn-large red go-all-resources" href="/am-admin/autores">
                <span class="icon-cross"></span>
            </a>
		</div>
	</div>

    <form class="author-form" id="author-form" enctype="multipart/form-data">

        <input type="hidden" id="_token" value="<?php echo e(csrf_token()); ?>">
        <input type="hidden" id="_id" value="<?php echo e($author->_id); ?>">
        <input type="hidden" id="_src" value="authors">

        <ul class="tabs top-tabs">
            <li class="tab">
                <a class="active" href="#ajustes-basicos">Ajustes básicos</a>
            </li>
            <li class="tab">
                <a href="#especialidades">Especialidades</a>
            </li>
            <li class="tab">
                <a href="#seo">SEO</a>
            </li>
        </ul>

        <div id="ajustes-basicos" class="content-tabs">

            <div class="row">

                <div class="col s12 m5 col-image">

                    <?php if(isset($author->image)): ?>
                        <img id="resource-image" src="<?php echo e($author->image); ?>" alt="">
                        <input type="hidden" id="image-url" name="image-url" value="<?php echo e($author->image); ?>">
                    <?php else: ?>
                        <img id="resource-image" src="https://amolca.webussines.com/uploads/authors/no-author-image.png" alt="">
                        <input type="hidden" id="image-url" name="image-url">
                    <?php endif; ?>

                    <div class="circle-preloader preloader-wrapper big active">
                        <div class="spinner-layer spinner-green-only">
                            <div class="circle-clipper left">
                                <div class="circle"></div>
                            </div>
                            <div class="gap-patch">
                                <div class="circle"></div>
                            </div>
                            <div class="circle-clipper right">
                                <div class="circle"></div>
                            </div>
                        </div>
                    </div>

                    <div class="global-upload-wrap">

                        <p id="image-error" class="error"></p>

                        <p class="desc">
                            El archivo debe pesar menos de 25mb.<br/>
                            Las medidas recomendadas son <b>250 x 250</b> (en pixeles).
                        </p>

                        <input type="button" id="save-file-btn" class="save" value="Guardar imagen">

                        <div class="file-upload-wrapper">
                            <button id="upload-file-btn" class="upload">Modificar imagen</button>
                            <input type="file" id="image" name="image">
                        </div>
                    </div>

                </div>

                <div class="col s12 m7">

                    <div class="form-group col s12 m12">
                        <label for="name"><span class="required">*</span> Nombre del autor:</label>
                        <input type="text" name="name" id="name" value="<?php echo e($author->name); ?>">
                    </div>

                    <div class="form-group col s12 m12">
                        <label for="description">Descripción:</label>
                        <textarea name="description" id="description"><?php echo e($description); ?></textarea>
                    </div>

                </div>
                
            </div>

        </div>

        <div id="especialidades" class="content-tabs">
            <div class="row specialties">
                <?php $__currentLoopData = $specialties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specialty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($specialty->top): ?>

                        <div class="col s12 m6">
                            <div class="form-group parent">

                                <label for="specialty-<?php echo e($specialty->_id); ?>">
                                    <?php $checked = ''; ?>
                                    
                                    <?php $__currentLoopData = $author->specialty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $selected): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            if($selected->_id == $specialty->_id){
                                                $checked = 'checked="checked"';
                                            }
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <input type="checkbox" name="specialty" id="specialty-<?php echo e($specialty->_id); ?>"  <?php echo e($checked); ?> value="<?php echo e($specialty->_id); ?>">

                                    <span><?php echo e($specialty->title); ?></span>
                                </label>

                            </div>

                            <div class="childs">
                                
                                <?php $__currentLoopData = $specialty->childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <div class="form-group col s6 m6">
                                        <label for="specialty-<?php echo e($child->_id); ?>">
                                            <?php $checked = ''; ?>
                                            
                                            <?php $__currentLoopData = $author->specialty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $selected): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    if($selected->_id == $child->_id){
                                                        $checked = 'checked="checked"';
                                                    }
                                                ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            <input type="checkbox" name="specialty" id="specialty-<?php echo e($child->_id); ?>"  <?php echo e($checked); ?> value="<?php echo e($child->_id); ?>">

                                            <span><?php echo e($child->title); ?></span>
                                        </label>
                                    </div>
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>

                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <div id="seo" class="content-tabs">
            
            <div class="row valign-wrapper">
                <div class="col s12 m4">
                    <p class="subtitle">Meta titulo:</p>
                </div>

                <div class="form-group col s12 m8">
                    <label for="meta-title">Meta titulo:</label>
                    <input type="text" id="meta-title" name="meta-title" placeholder="Meta titulo del autor..." value="<?php if(isset($author->metaTitle)): ?> <?php echo e($author->metaTitle); ?> <?php endif; ?>">
                </div>
            </div>

            <div class="row valign-wrapper">
                <div class="col s12 m4">
                    <p class="subtitle">Meta descripción:</p>
                </div>

                <div class="form-group col s12 m8">
                    <label for="meta-description">Meta descripción:</label>
                    <textarea rows="3" id="meta-description" name="meta-description" placeholder="Meta descripción del autor..."><?php if(isset($author->metaDescription)): ?> <?php echo e($author->metaDescription); ?> <?php endif; ?></textarea>
                </div>
            </div>

            <div class="row valign-wrapper">
                <div class="col s12 m4">
                    <p class="subtitle">Meta etiquetas:</p>
                </div>

                <div class="form-group col s12 m8">
                    <label for="meta-tags">Meta etiquetas:</label>
                    
                        <?php if(isset($author->metaTags) && count($author->metaTags) > 0): ?>
                            <textarea rows="3" id="meta-tags" name="meta-tags" placeholder="Meta etiquetas del autor..."><?php $__currentLoopData = $author->metaTags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($tag); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></textarea>
                        <?php else: ?>
                            <textarea rows="3" id="meta-tags" name="meta-tags" placeholder="Separar cada etiqueta con una comma ( , )..."></textarea>
                        <?php endif; ?>
                </div>
            </div>

        </div>

    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.account', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>