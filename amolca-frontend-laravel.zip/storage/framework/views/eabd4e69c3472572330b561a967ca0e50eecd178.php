<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
	<head>
		<meta charset="UTF-8">
		<title><?php echo $__env->yieldContent('title'); ?></title>
		<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
		<link rel="icon" type="image/x-icon" href="<?php echo e(asset('img/common/favicon.ico')); ?>">

		<link rel="stylesheet" href="<?php echo e(asset('css/fonts.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
		<!--MATERIALIZE STYLES-->
		<link rel="stylesheet" href="<?php echo e(asset('libs/materialize/css/materialize.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('libs/icomoon/icomoon.css')); ?>">
		<?php echo $__env->yieldContent('styles'); ?>

	</head>
	<body>

		<?php echo $__env->make('layouts.partials.top-bar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		<?php echo $__env->make('layouts.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		
		<div class="main <?php echo $__env->yieldContent('contentClass'); ?>">
			<?php echo $__env->yieldContent('content'); ?>
		</div>

		<script src="<?php echo e(asset('js/jquery-3.3.1.min.js')); ?>"></script>
		<script src="<?php echo e(asset('libs/materialize/js/materialize.min.js')); ?>"></script>
		<script src="<?php echo e(asset('js/common.js')); ?>"></script>
		<?php echo $__env->yieldContent('scripts'); ?>


	<?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->make('layouts.partials.bottom-bar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>