<?php $__env->startSection('title', "$book->title - Amolca Editorial Médica y Odontológica"); ?>

<!--Add single books styles-->
<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/single-book.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentClass', 'page-container book'); ?>
<?php $__env->startSection('content'); ?>

<div class="content-container">

	<div class="row">
		<div class="col s12 l5 image-book">
			<div id="image-container">
				<div class="material-placeholder">
					<img alt="<?php echo e($book->title); ?>" title="<?php echo e($book->title); ?>" class="materialboxed" src="<?php echo e($book->image); ?>">
				</div>

				<!--Countries loop for scroll info interaction-->
				<?php $__currentLoopData = $book->countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($country->name == $active_country && $country->price > 0 && $country->state == "STOCK"): ?>
					<div class="scroll-info">
						<p class="price"><?php echo '$' . number_format($country->price, 0, ',', '.'); ?></p>
						<div class="add-to-cart">
							<input placeholder="Cantidad..." type="number">
							<a class="button danger waves-effect waves-light">Añadir al carrito</a>
						</div>
					</div>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</div>
		</div>
		<div class="col s12 l7 summary-book">
			<h1 class="name">
				<?php echo e($book->title); ?>

			</h1>

			<h3 class="author">

				<!--Authors loop-->
				<?php $__currentLoopData = $book->author; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<span>
						<a href="/autor/<?php echo e($author->slug); ?>"> <?php echo e($author->name); ?> </a>
					</span>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</h3>

			<?php $__currentLoopData = $book->countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($country->name == $active_country && $country->price > 0 && $country->state == "STOCK"): ?>
					<p class="price"><?php echo '$' . number_format($country->price, 0, ',', '.'); ?></p>
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			<p class="shipping">¡Envío gratis a cualquier ciudad de Colombia!</p>
			<p class="versions">Disponible en:

				<?php $__currentLoopData = $book->version; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $version): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						
					<!--Paper version icon-->
					<?php if($version == "PAPER"): ?>
						<a class="version-btn tooltipped" data-position="top" data-tooltip="Papel" title="Papel">
							<span class="icon-book"></span>
						</a>
					<?php endif; ?>
					
					<!--Ebook version icon-->
					<?php if($version == "EBOOK"): ?>
						<a class="version-btn tooltipped" data-position="top" data-tooltip="Ebook" title="Ebook">
							<span class="icon-document-text"></span>
						</a>
					<?php endif; ?>

					<!--Video version icon-->
					<?php if($version == "VIDEO"): ?>
						<a class="version-btn tooltipped" data-position="top" data-tooltip="Vídeo" title="Vídeo">
							<span class="icon-media-play"></span>
						</a>
					<?php endif; ?>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</p>

			<?php $__currentLoopData = $book->countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($country->name == $active_country && $country->price > 0 && $country->state == "STOCK"): ?>
					<div class="add-to-cart">
						<input placeholder="Cantidad..." type="number">
						<a class="button danger waves-effect waves-light">Añadir al carrito</a>
					</div>
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			<ul class="collapsible">

				<!--Book description-->
				<?php if(isset($book->description) && $book->description !== ""): ?>
					<li class="collapsible-item">
						<div class="collapsible-header">
							<span class="icon-plus"></span> Descripción
						</div>
						<div class="collapsible-body">
							<?php echo $book->description; ?>

						</div>
					</li>
				<?php endif; ?>

				<!--Book index-->
				<?php if(isset($book->index) && $book->index !== ""): ?>
					<li class="collapsible-item">
						<div class="collapsible-header">
							<span class="icon-plus"></span> Índice
						</div>
						<div class="collapsible-body">
							<?php echo $book->index; ?>

						</div>
					</li>
				<?php endif; ?>
				
				<!--Book keypoints-->
				<?php if(isset($book->keyPoints) && $book->keyPoints !== ""): ?>
					<li class="collapsible-item">
						<div class="collapsible-header">
							<span class="icon-plus"></span> Puntos clave
						</div>
						<div class="collapsible-body">
							<?php echo $book->keyPoints; ?>

						</div>
					</li>
				<?php endif; ?>
			</ul>

		</div>
	</div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>