<?php $__env->startSection('title', "Libros de $specialty->title - Amolca Editorial Médica y Odontológica"); ?>

<?php $__env->startSection('contentClass', 'page-container specialty'); ?>
<?php $__env->startSection('content'); ?>
<div class="specialty-title">
	<h2><?php echo e($specialty->title); ?></h2>
</div>

<div class="content-container">

	<div class="books-loop items-per-page-4">

		<?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="item">
				<a class="contain-img" href="/<?php echo e($book->slug); ?>">
					<img alt="<?php echo e($book->title); ?>" title="<?php echo e($book->title); ?>" src="<?php echo e($book->image); ?>">
				</a>
				<!--Versions book loop-->
				<div class="versions">
					<?php $__currentLoopData = $book->version; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $version): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						
						<!--Paper version icon-->
						<?php if($version == "PAPER"): ?>
							<a class="version-btn tooltipped" data-position="top" data-tooltip="Papel" title="Papel">
								<span class="icon-book"></span>
							</a>
						<?php endif; ?>
						
						<!--Ebook version icon-->
						<?php if($version == "EBOOK"): ?>
							<a class="version-btn tooltipped" data-position="top" data-tooltip="Ebook" title="Ebook">
								<span class="icon-document-text"></span>
							</a>
						<?php endif; ?>

						<!--Video version icon-->
						<?php if($version == "VIDEO"): ?>
							<a class="version-btn tooltipped" data-position="top" data-tooltip="Vídeo" title="Vídeo">
								<span class="icon-media-play"></span>
							</a>
						<?php endif; ?>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				<div class="info">
					<h3 class="name">
						<a href="/<?php echo e($book->slug); ?>"><?php echo e($book->title); ?></a>
					</h3>
					<p class="authors">

						<!--Authors loop-->
						<?php $__currentLoopData = $book->author; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<span>
								<a href="/autor/<?php echo e($author->slug); ?>"><?php echo e($author->name); ?> </a>
							</span>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</p>

					<!--Countries loop-->
					<?php $__currentLoopData = $book->countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<!--Show price if country is the actual-->
						<?php if($country->name == $active_country): ?>
							<div class="actions">
								<p class="price" id="price"><?php echo '$' . number_format($country->price, 0, ',', '.'); ?></p>
								<p class="btns">
									<a class="cart-btn tooltipped" data-position="top" data-tooltip="Añadir al carrito">
										<span class="icon-add_shopping_cart"></span>
									</a>
									<a class="hearth-btn tooltipped" data-position="top" data-tooltip="Añadir a mi lista de deseos">
										<span class="icon-heart-outline"></span>
									</a>
								</p>
							</div>
						<?php endif; ?>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				</div>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('ecommerce.layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>