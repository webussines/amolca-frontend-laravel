<?php $__env->startSection('title', 'Especialidad: ' . $specialty->title . ' - Admin Amolca'); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/admin/single-specialty.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('libs/select2/css/select2.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src='https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=1icfygu7db6ym5ibmufjkk2myppelx6v827sc9rq8xt1eo2n'></script>
<script src="<?php echo e(asset('libs/select2/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/admin/single-specialty.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentClass', 'single single-specialty'); ?>
<?php $__env->startSection('content'); ?>

    <div class="loader hidde">
        <div class="progress">
            <div class="indeterminate"></div>
        </div>
    </div>

    <div class="fixed-action-btn">
        <a class="btn-floating btn-large green save-resource">
            <span class="icon-save1"></span>
        </a>
        <a class="btn-floating btn-large red go-all-resources" href="/am-admin/especialidades">
            <span class="icon-cross"></span>
        </a>
    </div>

    <div class="row single section-header valign-wrapper">
		<div class="col s12 m10 l10">
			<p class="title"> <?php echo e($specialty->title); ?> </p>
		</div>
		<div class="col s12 m2 l2 actions">
            <a class="btn-floating btn-large green save-resource">
                <span class="icon-save1"></span>
            </a>
            <a class="btn-floating btn-large red go-all-resources" href="/am-admin/especialidades">
                <span class="icon-cross"></span>
            </a>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.account', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>