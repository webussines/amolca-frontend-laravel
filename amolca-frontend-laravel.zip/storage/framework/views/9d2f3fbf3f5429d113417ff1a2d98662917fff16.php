<?php $__env->startSection('title', 'Mi cuenta - Admin Amolca'); ?>

<?php $__env->startSection('contentClass', 'dashboard'); ?>
<?php $__env->startSection('content'); ?>
	<?php echo e(session('user')->_id); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.account', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>