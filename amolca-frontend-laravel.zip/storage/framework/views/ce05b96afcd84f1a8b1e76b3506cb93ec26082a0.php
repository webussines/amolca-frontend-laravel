<?php $__env->startSection('title', 'Libro: ' . $book->title . ' - Admin Amolca'); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/admin/single-book.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('libs/select2/css/select2.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src='https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=1icfygu7db6ym5ibmufjkk2myppelx6v827sc9rq8xt1eo2n'></script>
<script src="<?php echo e(asset('libs/select2/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/admin/books/single.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentClass', 'single single-specialty'); ?>
<?php $__env->startSection('content'); ?>

    <div class="loader top hidde">
        <div class="progress">
            <div class="indeterminate"></div>
        </div>
    </div>

	<div class="row single section-header valign-wrapper">
		<div class="col s12 m10 l10">
			<p class="title"> <?php echo e($book->title); ?> </p>
		</div>
		<div class="col s12 m2 l2 actions">
            <a class="btn-floating btn-large green save-resource">
                <span class="icon-save1"></span>
            </a>
            <a class="btn-floating btn-large red go-all-resources" href="/am-admin/libros">
                <span class="icon-cross"></span>
            </a>
		</div>
	</div>

    <form id="book-edit" class="book-edit">
        <input type="hidden" id="_token" value="<?php echo e(csrf_token()); ?>">
        <input type="hidden" id="id" value="<?php echo e($book->_id); ?>">

        <ul class="tabs top-tabs">
            <li class="tab">
                <a class="active" href="#ajustes-basicos">Ajustes básicos</a>
            </li>
            <li class="tab">
                <a href="#especialidades">Especialidades</a>
            </li>
            <li class="tab">
                <a href="#ficha">Ficha técnica</a>
            </li>
            <li class="tab">
                <a href="#atributos">Atributos</a>
            </li>
            <li class="tab">
                <a href="#precios">Precios</a>
            </li>
        </ul>

        <div id="ajustes-basicos" class="content-tabs">

            <div class="row">
                <div class="col s12 m5 col-image">
                    <img src="<?php echo e($book->image); ?>" alt="<?php echo e($book->title); ?>">
                </div>

                <div class="col s12 m7">

                    <div class="form-group col s12 m12">
                        <label for="title"><span class="required">*</span> Título del libro:</label>
                        <input type="text" name="title" id="title" value="<?php echo e($book->title); ?>">
                    </div>

                    <div class="form-group col s12 m6">
                        <label for="isbn"><span class="required">*</span> ISBN del libro:</label>
                        <input type="text" name="isbn" id="isbn" value="<?php echo e($book->isbn); ?>">
                    </div>

                    <div class="form-group col s12 m6">
                        <label for="state">Estado:</label>
                        <select name="state" id="state" class="normal-select">
                            <option <?php if($book->state == 'PUBLISHED'): ?> selected <?php endif; ?> value="PUBLISHED">Publicado</option>
                            <option <?php if($book->state == 'DRAFT'): ?> selected <?php endif; ?> value="DRAFT">Borrador</option>
                            <option <?php if($book->state == 'TRASH'): ?> selected <?php endif; ?> value="TRASH">En papelera</option>
                        </select>
                    </div>

                    <div class="col s12 col-versions">
                        <div class="version">
                            <p>Versiones:</p>
                        </div>

                        <?php
                            $paper = false;
                            $ebook = false;
                            $video = false;
                        ?>

                        <?php $__currentLoopData = $book->version; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $version): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                if($version == 'PAPER'){
                                    $paper = true;
                                } else if($version == 'EBOOK'){
                                    $ebook = true;
                                } else if($version == 'VIDEO'){
                                    $video = true;
                                }
                            ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div class="version">
                            <label for="version-paper">
                                <input type="checkbox" name="version" id="version-paper" <?php if($paper): ?> checked="checked" <?php endif; ?> value="PAPER">
                                <span>Papel</span>
                            </label>
                        </div>

                        <div class="version">
                            <label for="version-video">
                                <input type="checkbox" name="version" id="version-video" <?php if($video): ?> checked="checked" <?php endif; ?> value="VIDEO">
                                <span>Vídeo</span>
                            </label>
                        </div>

                        <div class="version">
                            <label for="version-ebook">
                                <input type="checkbox" name="version" id="version-ebook" <?php if($ebook): ?> checked="checked" <?php endif; ?> value="EBOOK">
                                <span>Ebook</span>
                            </label>
                        </div>
                    </div>

                    <div class="form-group col s12 m12">
                        <label for="description">Descripción:</label>
                        <textarea name="description" id="description"><?php if(isset($book->description)): ?> <?php echo e($book->description); ?> <?php endif; ?></textarea>
                    </div>

                </div>
            </div>

            <div class="row">
                
                <ul class="tabs inside-tabs">
                    <li class="tab">
                        <a class="active" href="#indice">Índice</a>
                    </li>
                    <li class="tab">
                        <a href="#puntos-clave">Puntos clave</a>
                    </li>
                </ul>

                <div id="indice" class="content-tabs subtab">
                    <div class="form-group">
                        <textarea name="index" id="index" class="common-editor"><?php if(isset($book->index)): ?> <?php echo e($book->index); ?> <?php endif; ?></textarea>
                    </div>
                </div>
                <div id="puntos-clave" class="content-tabs subtab">
                    <div class="form-group">
                        <textarea name="key-points" id="key-points" class="common-editor"><?php if(isset($book->keyPoints)): ?> <?php echo e($book->keyPoints); ?> <?php endif; ?></textarea>
                    </div>
                </div>

            </div>

        </div>

        <div id="especialidades" class="content-tabs">
            <div class="row specialties">
                <?php $__currentLoopData = $specialties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specialty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($specialty->top): ?>

                        <div class="col s12 m6">
                            <div class="form-group parent">

                                <label for="specialty-<?php echo e($specialty->_id); ?>">
                                    <?php $checked = ''; ?>
                                    
                                    <?php $__currentLoopData = $book->specialty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $selected): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            if($selected->_id == $specialty->_id){
                                                $checked = 'checked="checked"';
                                            }
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <input type="checkbox" name="specialty" id="specialty-<?php echo e($specialty->_id); ?>"  <?php echo e($checked); ?> value="<?php echo e($specialty->_id); ?>">

                                    <span><?php echo e($specialty->title); ?></span>
                                </label>

                            </div>

                            <div class="childs">
                                
                                <?php $__currentLoopData = $specialty->childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <div class="form-group col s6 m6">
                                        <label for="specialty-<?php echo e($child->_id); ?>">
                                            <?php $checked = ''; ?>
                                            
                                            <?php $__currentLoopData = $book->specialty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $selected): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    if($selected->_id == $child->_id){
                                                        $checked = 'checked="checked"';
                                                    }
                                                ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            <input type="checkbox" name="specialty" id="specialty-<?php echo e($child->_id); ?>"  <?php echo e($checked); ?> value="<?php echo e($child->_id); ?>">

                                            <span><?php echo e($child->title); ?></span>
                                        </label>
                                    </div>
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>

                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <div id="ficha" class="content-tabs">

                
            

            <div class="row">
                <div class="col s6 m5">
                    <label for="publication-year"><span class="required">*</span> Año de publicación:</label>
                    <input type="text" readonly id="publication-year-name" name="publication-year-name" value="Año de publicación">
                </div>
                <div class="col s6 m5">
                    <label for="publication-year"><span class="required">*</span> Valor:</label>
                    <input type="number" id="publication-year" name="publication-year" value="<?php if(isset($book->publicationYear)) { echo $book->publicationYear; } else { echo 0; } ?>">
                </div>
            </div>

            <div class="row">
                <div class="col s6 m5">
                    <label for="number-pages"><span class="required">*</span> Número de páginas:</label>
                    <input type="text" readonly id="number-pages-name" name="number-pages-name" value="Número de páginas">
                </div>
                <div class="col s6 m5">
                    <label for="number-pages"><span class="required">*</span> Valor:</label>
                    <input type="number" id="number-pages" name="number-pages" value="<?php if(isset($book->numberPages)) { echo $book->numberPages; } else { echo 0; } ?>">
                </div>
            </div>

            <div class="row">
                <div class="col s6 m5">
                    <label for="number-volumes"><span class="required">*</span> Número de tomos:</label>
                    <input type="text" readonly id="volumes-name" name="volumes-name" value="Número de tomos">
                </div>
                <div class="col s6 m5">
                    <label for="number-volumes"><span class="required">*</span> Valor:</label>
                    <input type="number" id="number-volumes" name="number-volumes" value="<?php if(isset($book->volume)) { echo $book->volume; } else { echo 0; } ?>">
                </div>
            </div>

        </div>

        <div id="atributos" class="content-tabs">
            
            <?php $__currentLoopData = $book->attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <div class="row row-attr">
                    
                    <div class="col s12 m5">
                        <label for="name"><span class="required">*</span> Nombre:</label>
                        <input type="text" id="name" class="attr-name" name="name" value="<?php echo e($attr->name); ?>">
                    </div>
                    <div class="col s12 m5">
                        <label for="value"><span class="required">*</span> Valor:</label>
                        <input type="text" id="value" class="attr-value" name="value" value="<?php echo e($attr->value); ?>">
                    </div>
                    <div class="col s12 m2">
                        <label>Acciones:</label>
                        <div>
                            <button class="button primary delete-attribute">Borrar</button>
                        </div>
                    </div>

                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <div id="precios" class="content-tabs">
            
            <?php $__currentLoopData = $book->countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <div class="row row-country">
                    
                    <div class="col s12 m4">
                        <label for="name"><span class="required">*</span> País:</label>
                        <input type="text" readonly class="country-name" id="name" name="name" value="<?php echo e($country->name); ?>">
                    </div>
                    <div class="col s12 m2">
                        <label for="price"><span class="required">*</span> Precio:</label>
                        <input type="text" class="country-price" id="price" name="price" value="<?php echo e($country->price); ?>">
                    </div>
                    <div class="col s12 m2">
                        <label for="country-state">Estado:</label>
                        <select class="country-state normal-select" name="country-state" id="country-state">
                            <option value="STOCK" <?php if($country->state == "STOCK"): ?> selected <?php endif; ?>>Disponible</option>
                            <option value="RESERVED" <?php if($country->state == "RESERVED"): ?> selected <?php endif; ?>>Reservado</option>
                            <option value="SPENT" <?php if($country->state == "SPENT"): ?> selected <?php endif; ?>>Agotado</option>
                        </select>
                    </div>
                    <div class="col s12 m2">
                        <label for="quantity">Cantidad:</label>
                        <input type="text" class="country-quantity" id="quantity" name="quantity" value="<?php echo e($country->quantity); ?>">
                    </div>
                    <div class="col s12 m2">
                        <label>Acciones:</label>
                        <div>
                            <button class="button primary delete-attribute">Borrar</button>
                        </div>
                    </div>

                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="row">
                <div class="col s12">
                    <input type="button" id="add-country" class="button primary" value="Agregar un país">
                </div>
            </div>

        </div>

        <div class="book-navigation">
            <?php if($previousBook !== null): ?>
                <a class="btn-navigation previous" href="<?php echo e($previousBook->_id); ?>?orderby=<?php echo e($navOrderby); ?>&orderby=<?php echo e($navOrder); ?>"><span class="icon-arrow-left2"></span> Anterior</a>
            <?php endif; ?>

            <?php if($nextBook !== null): ?>
                <a class="btn-navigation next" href="<?php echo e($nextBook->_id); ?>?orderby=<?php echo e($navOrderby); ?>&orderby=<?php echo e($navOrder); ?>">Siguiente <span class="icon-arrow-right2"></span></a>
            <?php endif; ?>
        </div>

        <div class="fixed-action-btn">
            <a class="btn-floating btn-large green save-resource">
                <span class="icon-save1"></span>
            </a>
            <a class="btn-floating btn-large red go-all-resources" href="/am-admin/libros">
                <span class="icon-cross"></span>
            </a>
        </div>

    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.account', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>