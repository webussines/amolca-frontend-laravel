<div class="header" id="header">

    <p class="site-title">Amolca</p>
    
    <a class="user-btn dropdown-btn" data-target="user-menu-dropdown">
        <span class="icon-user"></span> <?php echo e(session('user')->name); ?> <?php echo e(session('user')->lastname); ?>

    </a>

    <ul id="user-menu-dropdown" class="user-menu dropdown-content">
        <li><a href="/am-admin/mi-cuenta">Mi cuenta</a></li>
        <li><a href="/am-admin/logout">Cerrar sesión</a></li>
    </ul>

</div>