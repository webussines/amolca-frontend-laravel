@extends('admin.layouts.account')

@section('title', 'Ver: Libro - Admin Amolca')

@section('contentClass', 'single-books')
@section('content')
	Ver libro
@endsection