@extends('ecommerce.layouts.site')

@section('title', 'Mi carrito - Amolca Editorial Médica y Odontológica')

@section('contentClass', 'page-container')
@section('content')
Contenido de <b>Carrito de compras</b>
@endsection