@extends('ecommerce.layouts.site')

@section('title', 'Iniciar sesión - Amolca Editorial Médica y Odontológica')

@section('contentClass', 'page-container')
@section('content')
Contenido de <b>Iniciar sesión</b>
@endsection