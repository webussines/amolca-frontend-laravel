<div id="bottom-bar">
	<div class="item" id="copy">
		Copyright 2018 Editorial Amolca
	</div>
	<div class="item">
		Términos y condiciones
	</div>
	<div class="item">
		Políticas y privacidad
	</div>
	<div class="item" id="designed">
		Diseñado por: <a href="https://www.webussines.com" target="_blank">WeBussines</a>
	</div>
</div>