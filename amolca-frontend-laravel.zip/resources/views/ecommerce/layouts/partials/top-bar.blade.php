<div class="top-bar">
	<div id="social-top-bar">
		<ul class="social-networks top">
			<li >
				<a target="_blank" href="#" class="waves-effect waves-light bg-blue">
					<i class="icon-facebook1"></i>
				</a>
			</li>
			<li >
				<a target="_blank" href="#" class="waves-effect waves-light bg-blue">
					<i class="icon-instagram1"></i>
				</a>
			</li>
			<li >
				<a target="_blank" href="#" class="waves-effect waves-light bg-blue">
					<i class="icon-twitter1"></i>
				</a>
			</li>
		</ul>
	</div>
	<ul id="top-bar-btns">
		<li>
			<a class="waves-effect waves-light" id="cart-btn" routerlink="/carrito" href="/carrito">
				<i class="icon-shopping-cart1"></i>
				<span>$0.000</span>
			</a>
		</li>
		<li>
			<a id="login-btn" routerlink="/iniciar-sesion" class="waves-effect waves-light normal" href="/iniciar-sesion">
				<i class="icon-person"></i>
				<span>Inicar sesión</span>
			</a>
		</li>
	</ul>
</div>